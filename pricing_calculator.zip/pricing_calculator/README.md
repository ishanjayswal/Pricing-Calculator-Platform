# Pricing Calculator Platform

A web-based platform that allows companies to manage tools, sections, and components to generate pricing estimates. This platform supports user authentication, CRUD operations, and pricing calculations.

---

## Features

- **User Authentication**: Secure login and registration.
- **Tool Management**: Create and manage tools and sections.
- **Pricing Calculation**: Estimate tool pricing based on sections and components.

---

## Tech Stack

- **Backend**: Flask (Python)
- **Database**: SQLAlchemy (PostgreSQL, SQLite, or MySQL)
- **Authentication**: Flask-JWT-Extended
- **Frontend**: [To be implemented later]

---

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/pricing-calculator.git
   cd pricing-calculator
