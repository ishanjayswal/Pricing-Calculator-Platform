from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from extensions import db
from models import Company, Tool, Section, Component

app = Flask(__name__)

# Configure JWT
app.config['JWT_SECRET_KEY'] = 'super-secret-key'
jwt = JWTManager(app)

# Add your routes here
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    new_company = Company(name=data['name'], email=data['email'], password=data['password'])
    db.session.add(new_company)
    db.session.commit()
    return jsonify({"message": "Company registered successfully"}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    company = Company.query.filter_by(email=data['email'], password=data['password']).first()
    if company:
        access_token = create_access_token(identity=company.id)
        return jsonify(access_token=access_token), 200
    return jsonify({"message": "Invalid credentials"}), 401

from models import Tool, Section, Component

@app.route('/tools', methods=['POST'])
@jwt_required()
def create_tool():
    data = request.get_json()
    new_tool = Tool(name=data['name'], version=data['version'], company_id=get_jwt_identity())
    db.session.add(new_tool)
    db.session.commit()
    return jsonify({"message": "Tool created successfully"}), 201

@app.route('/tools/<int:tool_id>', methods=['GET'])
@jwt_required()
def get_tool(tool_id):
    tool = Tool.query.get_or_404(tool_id)
    return jsonify({"name": tool.name, "version": tool.version, "status": tool.status})

@app.route('/tools/<int:tool_id>', methods=['PUT'])
@jwt_required()
def update_tool(tool_id):
    tool = Tool.query.get_or_404(tool_id)
    data = request.get_json()
    tool.name = data.get('name', tool.name)
    tool.version = data.get('version', tool.version)
    db.session.commit()
    return jsonify({"message": "Tool updated successfully"}), 200

@app.route('/tools/<int:tool_id>', methods=['DELETE'])
@jwt_required()
def delete_tool(tool_id):
    tool = Tool.query.get_or_404(tool_id)
    db.session.delete(tool)
    db.session.commit()
    return jsonify({"message": "Tool deleted successfully"}), 200

@app.route('/tools/<int:tool_id>/publish', methods=['POST'])
@jwt_required()
def publish_tool(tool_id):
    tool = Tool.query.get_or_404(tool_id)
    tool.status = 'live'
    db.session.commit()
    return jsonify({"message": "Tool published successfully"}), 200

@app.route('/estimate', methods=['POST'])
@jwt_required()
def calculate_estimate():
    data = request.get_json()
    component_ids = data.get('component_ids', [])
    components = Component.query.filter(Component.id.in_(component_ids)).all()
    total_cost = sum(component.pricing for component in components)
    return jsonify({"total_cost": total_cost}), 200