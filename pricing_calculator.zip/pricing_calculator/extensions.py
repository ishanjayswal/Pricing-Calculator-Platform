from flask_sqlalchemy import SQLAlchemy

# Initialize the database
db = SQLAlchemy()