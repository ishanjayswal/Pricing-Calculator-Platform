from flask import Flask
from extensions import db
from routes import app  # Import the Flask app from routes.py

# Configure the database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['JWT_SECRET_KEY'] = 'super-secret-key'

# Initialize the database with the app
db.init_app(app)

# Import models after initializing db
from models import Company, Tool, Section, Component

if __name__ == '__main__':
    # Create database tables if they don't exist
    with app.app_context():
        db.create_all()
    
    # Run the Flask app
    app.run(debug=True)